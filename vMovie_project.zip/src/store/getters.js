export default {
	isLoading: state => state.isLoading,
}