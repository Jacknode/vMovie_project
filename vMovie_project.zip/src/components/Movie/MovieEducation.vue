<template>
    <!--视频教育-->
</template>

<script>
    export default {
        name: "movie-education"
    }
</script>

<style scoped>

</style>
